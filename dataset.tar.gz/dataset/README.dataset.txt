# gate-polygon-mrym > 2025-01-12 5:11pm
https://universe.roboflow.com/dron-tstu5/gate-polygon-mrym

Provided by a Roboflow user
License: CC BY 4.0

